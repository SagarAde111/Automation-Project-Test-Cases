package TestCases_24;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestCasesAll {
 
	  WebDriver driver=null;
	  
	  @BeforeMethod ()
	  public void OpenBrowser()
    {
		  
		    System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	        driver=new ChromeDriver();
	    	driver.get("https://www.qa.jbktest.com/online-exam#Testing");
	    	driver.manage().window().maximize();
	    	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		  
    }
	 
	  
	  
	  
	  @Test (priority=1)
	  public void CheckSignupFunctionality()
	  
    {
			Actions actions = new Actions(driver);
			driver.findElement(By.xpath("//p[text()='Manual Testing(ISTQB)']")).click();
			driver.findElement(By.id("countbtn")).click();
			driver.findElement(By.id("loginmobile")).sendKeys("2222211111");
			driver.findElement(By.id("loginbtn")).click();
			driver.findElement(By.id("signup-tab")).click();
			driver.findElement(By.id("name")).sendKeys("sagar Ade");
			driver.findElement(By.id("emailid")).sendKeys("sagarade2061999@gmail.com");
			
			driver.findElement(By.id("mobile")).sendKeys("8446312847");
		    driver.findElement(By.id("agree")).click();
		    actions.sendKeys(Keys.ARROW_DOWN).perform();

			driver.findElement(By.id("emailbtn")).click();

			String ActualResult = driver.findElement(By.xpath("//*[text()='Mobile number already exists, please login with this mobile number']")).getText();
			String AxpecteddResult="Mobile number already exists, please login with this mobile number";
			//driver.close();
			Assert.assertEquals(ActualResult, AxpecteddResult);
			
	 }
	  
	
       @Test (priority=2)
       public void CheckExam10QuestionsFunctionality() 
       
     {
		  
		    driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
	      	String val=driver.findElement(By.name("count")).getAttribute("value");
		    System.out.println(" Attempted Questions --> " +val);
		    driver.findElement(By.id("countbtn")).click();
		    driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
		    driver.findElement(By.id("loginbtn")).click();
		    int num=Integer.parseInt(val);
		    for(int i=0;i<=num+1;i++)
		    	
	      {

			WebElement nextButton = driver.findElement(By.xpath("//*[@id='quizsection']/div[2]/a[1]"));
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("arguments[0].click()", nextButton);
		    driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");
		 
		  }
		
	    	    
		    driver.findElement(By.xpath("//*[text()='Submit']")).click();
		    String msg =driver.findElement(By.xpath("//*[text()='Your Result']")).getText();
		    System.out.println(msg);
		    
		    String expres="Your Result";
		    String actres=driver.findElement(By.xpath("//*[text()='Your Result']")).getText();
		   // driver.close();
			Assert.assertEquals(actres, expres);

			
	}
  
       @Test (priority=3)
	   public void CheckExam20QuestionsFunctionality()
	   
    {
    	 
 		     driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
 	       	 driver.findElement(By.xpath("//*[@id='quizcount']/div[1]/input[2]")).click();
 		     String val = driver.findElement(By.xpath("//*[@id='quizcount']/div[1]/input[2]")).getAttribute("value");
 		     System.out.println(" Attempted Questions --> " +val);
 		     driver.findElement(By.id("countbtn")).click();
 		     driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
 		     driver.findElement(By.id("loginbtn")).click();
 		     int num=Integer.parseInt(val);    
 		     for(int i=0;i<=num+2;i++)
 			
 		{

 			 WebElement nextButton = driver.findElement(By.xpath("//*[@id='quizsection']/div[2]/a[1]"));
 			 JavascriptExecutor js = (JavascriptExecutor)driver;
 			 js.executeScript("arguments[0].click()", nextButton);
 			 driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");
 		 
 		}
 		
 		    driver.findElement(By.id("qsubmit")).click();
 		   
 		    String msg =driver.findElement(By.xpath("//*[text()='Your Result']")).getText();
		    System.out.println(msg);
		    
		    String expectedResulte="Your Result";
	        String actualResult=driver.findElement(By.xpath("//*[text()='Your Result']")).getText();
	        //driver.close();
			Assert.assertEquals(actualResult, expectedResulte);	 
    	 
     }
     

       @Test  (priority=4)
	   public void CheckExam25QuestionsFunctionality()
	   
    {

 		  
 		    driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
 	        driver.findElement(By.xpath("//*[@id='quizcount']/div[1]/input[3]")).click();
 		    String val = driver.findElement(By.xpath("//*[@id='quizcount']/div[1]/input[3]")).getAttribute("value");
 		    System.out.println("Attempted Questions --> " +val);
 	        driver.findElement(By.id("countbtn")).click();
 		    driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
 		    driver.findElement(By.id("loginbtn")).click();
 		    int num=Integer.parseInt(val);
 		    for(int i=0;i<=num+2;i++)
 		    	
         {
 
            WebElement nextButton = driver.findElement(By.xpath("//*[@id='quizsection']/div[2]/a[1]"));
            JavascriptExecutor js = (JavascriptExecutor)driver;
 		    js.executeScript("arguments[0].click()", nextButton);
 		    driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");
 		 
 		 }
 		
 		    driver.findElement(By.id("qsubmit")).click();
 		    String msg =driver.findElement(By.xpath("//*[text()='Your Result']")).getText();
		    System.out.println(msg);
		    
		    String expectedResulte="Your Result";
		    String actualResult=driver.findElement(By.xpath("//*[text()='Your Result']")).getText();
		    //driver.close();
			Assert.assertEquals(actualResult, expectedResulte);
 		  
    	 
    }
     
       @Test (priority=5)
       public void checkAnswersFunctionality() 
            
    {  
    	 
 		    driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
 		
 		    String val=driver.findElement(By.name("count")).getAttribute("value");
 		    System.out.println(" Attempted Questions --> " +val);
 		    driver.findElement(By.id("countbtn")).click();
 	    	driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
 		    driver.findElement(By.id("loginbtn")).click();
 		    int num=Integer.parseInt(val);
 	        for(int i=0;i<=num+1;i++)
        {
 
 	    	WebElement nextButton = driver.findElement(By.xpath("//*[@id='quizsection']/div[2]/a[1]"));
 		    JavascriptExecutor js = (JavascriptExecutor)driver;
 	        js.executeScript("arguments[0].click()", nextButton);
 		    driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");
 		 
 	    }
 		
 		    driver.findElement(By.id("qsubmit")).click();
 		    driver.findElement(By.xpath("//*[text()='View Answer']")).click();
 		  
 		    WebElement CheckAndScrollDown= driver.findElement(By.xpath("//*[text()='Take a Quiz Again']"));
 		    JavascriptExecutor js = (JavascriptExecutor)driver;
 		    js.executeScript("arguments[0].scrollIntoView();",CheckAndScrollDown);
 		   
 	        String ActTextDisplay = driver.findElement(By.xpath("//*[text()='Take a Quiz Again']")).getText();
 		    String expTextDisplay = "Take a Quiz Again"	;
			//driver.close();
			Assert.assertEquals(ActTextDisplay, expTextDisplay);
 			 
    	 
     }
     
            
            

	   @Test (priority=6)
	   public void checkDownloadCertificateFunctionality()
	   
	{
		   
		
			
		    driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[1]/a")).click();
		    driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div[1]/div[2]/h1/a")).click();
		    driver.findElement(By.xpath("//*[@id='Placement-Policy']/div/div/a/div")).click();
			 
			String val=driver.findElement(By.name("count")).getAttribute("value");
			System.out.println(val);
			driver.findElement(By.id("countbtn")).click();
				
			driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
			driver.findElement(By.id("loginbtn")).click();
			driver.findElement(By.xpath("//*[@id='choices']/div[1]/label/div")).click();
			int num=Integer.parseInt(val);
		    for(int i=0;i<=num+1;i++)	
	     {

			WebElement nextButton = driver.findElement(By.xpath("//*[@id='quizsection']/div[2]/a[1]"));
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("arguments[0].click()", nextButton);
		    driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");
				 
		 }
				
		   	driver.findElement(By.id("qsubmit")).click();
		    driver.findElement(By.xpath("//*[text()='Download Your Certificate']")).click();
				   
		    String ActTextDisplay = driver.findElement(By.xpath("//h3[text()='Your Result']")).getText();
		    String ExpTextDisplay = "Your Result";
			//driver.close();
			Assert.assertEquals(ActTextDisplay, ExpTextDisplay);
			
	 }
	   
	   
	   
	    @Test (priority=7)
	    public void CheckMyAccountFunctionality()
	    
	 {
	    
			driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();

			driver.findElement(By.id("countbtn")).click();
			driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
			driver.findElement(By.id("loginbtn")).click();
			
			driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();

		    String TextDisplay = driver.findElement(By.xpath("//h4[text()='Dashboard']")).getText();
		    System.out.println(TextDisplay);
			
		    String ActWelcomeTextDisplay = driver.findElement(By.xpath("//*[text()='Welcome Sagar Ade,']")).getText();
		    String ExpWelcomeTextDisplay = "Welcome Sagar Ade,";
			//driver.close();
		    Assert.assertEquals(ActWelcomeTextDisplay, ExpWelcomeTextDisplay);
		    
		   
	 }
	    
	    
	    @Test (priority=8)
	    public void CheckHomeFunctionality()
	    
	 {
	    	
	    	driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();

	    	driver.findElement(By.id("countbtn")).click();
	    	driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
	    	driver.findElement(By.id("loginbtn")).click();
	    	driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
	    	driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[1]/a")).click(); // click on Home 
	    	

	        String TextDisplay = driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div[1]/div[2]/h1")).getText();
	        System.out.println(TextDisplay); //Take a Online Test Text Display
	         
	        String ActHomePage =  driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div[1]/div[2]/p")).getText();
            String ExpHomePage = "Check your experties & improve your skills";
			//driver.close();
			Assert.assertEquals(ActHomePage, ExpHomePage);	
	    	
	 }  

	    
	    
	   @Test (priority=9)
	   public void CheckAllJavaExamTopicsFunctionality()
	   
	{
	    
			Actions actions = new Actions(driver);

			driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
			driver.findElement(By.id("countbtn")).click();
			driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
			driver.findElement(By.id("loginbtn")).click();
			driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
			driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[1]/a")).click(); // click on Home 
			
			
		    driver.findElement(By.xpath("/html/body/div/div[1]/div[1]/div[3]/div[1]/a/div")).click();  // click on java test Topics
			    
		    actions.sendKeys(Keys.PAGE_DOWN).build().perform();
		      //identify element on scroll down
		    WebElement l = driver.findElement(By.xpath("//*[text()='jbktest Copyright @ 2020. All rights reserved.']"));
		    String sendit = l.getText();
		    System.out.println("Text obtained by scrolling down is :--> "+sendit);
		    
		      
		    actions.sendKeys(Keys.PAGE_UP).build().perform();
		      //identify element on scroll up
		    WebElement m = driver.findElement(By.xpath("//h3[text()='Java']"));
		    String sendnow = m.getText();
		    System.out.println("Text obtained by scrolling up is :--> "+sendnow);
		     // driver.quit();    	
		    
		    String ActTextDisplay = driver.findElement(By.xpath("//h3[text()='Java']")).getText();
		    String ExpTextDisplay = "Java";
			//driver.close();
			Assert.assertEquals(ActTextDisplay, ExpTextDisplay);
		    
		   
	 }
	        
	        
	   @Test (priority=10)
	   public void CheckAllPythonExamTopicsFunctionality()
		    
	 {
	        
	       Actions actions = new Actions(driver);

	       driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
	       driver.findElement(By.id("countbtn")).click();
	       driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
	       driver.findElement(By.id("loginbtn")).click();
	       driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
	       driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[1]/a")).click(); // click on Home 
	    		
	    		
	       driver.findElement(By.xpath("/html/body/div/div[1]/div[1]/div[3]/div[2]/a/div/p")).click();  // click on python test Topics
	    		    
	  	   actions.sendKeys(Keys.PAGE_DOWN).build().perform();
	  	     //identify element on scroll down
	  	   WebElement l = driver.findElement(By.xpath("//*[text()='jbktest Copyright @ 2020. All rights reserved.']"));
	  	   String sendit = l.getText();
	       System.out.println("Text obtained by scrolling down is :--> "+sendit);
	  	      
	       
	  	   actions.sendKeys(Keys.PAGE_UP).build().perform();
	  	     //identify element on scroll up
	  	   WebElement m = driver.findElement(By.xpath("//h3[text()='Python']"));
	  	   String sendnow = m.getText();
	       System.out.println("Text obtained by scrolling up is :--> "+sendnow);
	  	     // driver.quit();

	       String ActTextDisplay = driver.findElement(By.xpath("//h3[text()='Python']")).getText();
		   String ExpTextDisplay = "Python";
	   	  // driver.close();
	       Assert.assertEquals(ActTextDisplay,ExpTextDisplay);
			    
	        	
	 }
	        
	        
	    @Test (priority=11)
	    public void CheckAllMySQLExamTopicsFunctionality()
	 {
	        	
	    		
	    	Actions actions = new Actions(driver);


	    	driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
	    	driver.findElement(By.id("countbtn")).click();
	   		driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
	   		driver.findElement(By.id("loginbtn")).click();
	   		driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
	   		driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[1]/a")).click(); // click on Home 
	    		
	    		
	        driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div[3]/div[3]/a/div")).click();  // click on MySQL test Topics
	    		    
	        actions.sendKeys(Keys.PAGE_DOWN).build().perform();
	          //identify element on scroll down
		    WebElement l = driver.findElement(By.xpath("//*[text()='jbktest Copyright @ 2020. All rights reserved.']"));
	        String sendit = l.getText();
   	        System.out.println("Text obtained by scrolling down is :--> "+sendit);
   	        
	    	      
	    	actions.sendKeys(Keys.PAGE_UP).build().perform();
	         //identify element on scroll up
    	    WebElement m = driver.findElement(By.xpath("//h3[text()='MySQL']"));
   	        String sendnow = m.getText();
	        System.out.println("Text obtained by scrolling up is :--> "+sendnow);
	   	     // driver.quit();    
	    	     	
	        String ActTextDisplay = driver.findElement(By.xpath("//h3[text()='MySQL']")).getText();
		    String ExpTextDisplay = "MySQL";
			//driver.close();
			Assert.assertEquals(ActTextDisplay,ExpTextDisplay);
				     	
	        	
	 }  
	    
	    
	    
	        
	    @Test(priority=12)
	    public void CheckAllTestingExamTopicsFunctionality()
	   
	 {
		
			Actions actions = new Actions(driver);

			driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
			driver.findElement(By.id("countbtn")).click();
			driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
			driver.findElement(By.id("loginbtn")).click();
			driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
			driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[1]/a")).click(); // click on Home 
			
		    driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div[3]/div[4]/a/div")).click();  // click on Testing test Topics
			    
			actions.sendKeys(Keys.PAGE_DOWN).build().perform();
		     //identify element on scroll down
		    WebElement l = driver.findElement(By.xpath("//*[text()='jbktest Copyright @ 2020. All rights reserved.']"));
	        String sendit = l.getText();
	        System.out.println("Text obtained by scrolling down is :--> "+sendit);
		
	        
		    actions.sendKeys(Keys.PAGE_UP).build().perform();
		     //identify element on scroll up
	        WebElement m = driver.findElement(By.xpath("//*[@id='Testing']/h3"));
	        String sendnow = m.getText();
	        System.out.println("Text obtained by scrolling up is :--> "+sendnow);
	         // driver.quit();    
		    
		    String ActTextDisplay = driver.findElement(By.xpath("//*[@id='Testing']/h3")).getText();
		    String ExpTextDisplay = "Testing";
		    //driver.close();
		    Assert.assertEquals(ActTextDisplay,ExpTextDisplay);
	   	     
		 
	 }
	    
	    
	    
	 
	    @Test (priority=13)
	    public void CheckJavaCertificationExamTopicsFunctionality()
	   
	 {
		 
			  Actions actions = new Actions(driver);

	          driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div/a[3]")).click();  //Click on Java Certification

	          actions.sendKeys(Keys.PAGE_DOWN).build().perform();
		      //identify element on scroll down
		      WebElement l = driver.findElement(By.xpath("//*[text()='jbktest Copyright @ 2020. All rights reserved.']"));
		      String sendit = l.getText();
		      System.out.println("Text obtained by scrolling down is :--> "+sendit);
		      
		      
		      actions.sendKeys(Keys.PAGE_UP).build().perform();
		      //identify element on scroll up
		      WebElement m = driver.findElement(By.xpath("//h3[text()='Java Certification']"));
		      String sendnow = m.getText();
		      System.out.println("Text obtained by scrolling up is :--> "+sendnow);
		     // driver.quit();    
		   
		      driver.findElement(By.xpath("//p[text()='Abstraction']")).click(); //take a quiz of Abstraction
			
			 String val=driver.findElement(By.name("count")).getAttribute("value");
			 System.out.println("Attempted Questions --> " +val);
			 driver.findElement(By.id("countbtn")).click();
			 driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
			 driver.findElement(By.id("loginbtn")).click();
			 int num=Integer.parseInt(val);
			 for(int i=0;i<=num+2;i++)
				 
		    {

				WebElement nextButton = driver.findElement(By.xpath("//*[@id='quizsection']/div[2]/a[1]"));
				JavascriptExecutor js = (JavascriptExecutor)driver;
				js.executeScript("arguments[0].click()", nextButton);
				driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");
			 
	    	}
				    
			 
			driver.findElement(By.xpath("//*[text()='Submit']")).click();
			   
		    String msg =driver.findElement(By.xpath("//h3[text()='Your Result']")).getText();
			System.out.println(msg);
			    
			String ActTextDisplay=driver.findElement(By.xpath("//*[text()='Your Result']")).getText();
		    String ExpTextDisplay="Your Result";
			//driver.close();
			Assert.assertEquals(ActTextDisplay, ExpTextDisplay);
	    	    	 
		 
	 }
	    
	    
	    
	    
	    @Test (priority=14)
	    public void CheckAptitudeTestExamTopicsFunctionality()
	    
	 {
		 

			Actions actions = new Actions(driver);

	        driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div/a[4]")).click();  //Click on Aptitude Test

	        actions.sendKeys(Keys.PAGE_DOWN).build().perform();
		      //identify element on scroll down
		    WebElement l = driver.findElement(By.xpath("//*[text()='jbktest Copyright @ 2020. All rights reserved.']"));
		    String sendit = l.getText();
		    System.out.println("Text obtained by scrolling down is :--> "+sendit);
		
		    
		    actions.sendKeys(Keys.PAGE_UP).build().perform();
		      //identify element on scroll up
		    WebElement m = driver.findElement(By.xpath("//h3[text()='Aptitude Test']"));
	        String sendnow = m.getText();
	        System.out.println("Text obtained by scrolling up is :--> "+sendnow);
		     // driver.quit();    
		    
		    driver.findElement(By.xpath("//p[text()='Aptitude Test 1']")).click(); // take a quiz of Aptitude Test 1
			
			String val=driver.findElement(By.name("count")).getAttribute("value");
			System.out.println("Attempted Questions --> " +val);
			driver.findElement(By.id("countbtn")).click();
			driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
			driver.findElement(By.id("loginbtn")).click();
			int num=Integer.parseInt(val);
			for(int i=0;i<=num+1;i++)
				
			{

				WebElement nextButton = driver.findElement(By.xpath("//*[@id='quizsection']/div[2]/a[1]"));
				JavascriptExecutor js = (JavascriptExecutor)driver;
				js.executeScript("arguments[0].click()", nextButton);
				driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");
			 
			}
				    
		   driver.findElement(By.xpath("//a[text()='Submit']")).click();
    	   String hn =driver.findElement(By.xpath("//h3[text()='Your Result']")).getText();
	       System.out.println(hn);
			    
   	       String ActTextDisplay=driver.findElement(By.xpath("//*[text()='Your Result']")).getText();
		   String ExpTextDisplay="Your Result";
		   //driver.close();
		   Assert.assertEquals(ActTextDisplay, ExpTextDisplay);
	    	 		
		 
	 }
	    
	    
	    
	   @Test (priority=15)
	   public void CheckLogicalReasoningExamTopicsFunctionality()
	   
	 {
		
		   Actions actions = new Actions(driver);

	       driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div/a[5]")).click();  //Click on Logical Reasoning

	       actions.sendKeys(Keys.PAGE_DOWN).build().perform();
		      //identify element on scroll down
		   WebElement l = driver.findElement(By.xpath("//*[text()='jbktest Copyright @ 2020. All rights reserved.']"));
		   String sendit = l.getText();
	       System.out.println("Text obtained by scrolling down is :--> "+sendit);
		      
	       actions.sendKeys(Keys.PAGE_UP).build().perform();
		      //identify element on scroll up
	       WebElement m = driver.findElement(By.xpath("//*[@id='Logical-Reasoning']/h3"));
	       String sendnow = m.getText();
	       System.out.println("Text obtained by scrolling up is :--> "+sendnow);
		     // driver.quit();    
		    
		   driver.findElement(By.xpath("//*[@id='Logical-Reasoning']/div/div[1]/a/div")).click(); // take a quiz on Verification of Truth 10 Questions
			
		   String val=driver.findElement(By.name("count")).getAttribute("value");
		   System.out.println("Attempted Questions --> " +val);
		   driver.findElement(By.id("countbtn")).click();
		   driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
		   driver.findElement(By.id("loginbtn")).click();
		   int num=Integer.parseInt(val);
		   for(int i=0;i<=num+1;i++)
			   
		   {

				WebElement nextButton = driver.findElement(By.xpath("//*[@id='quizsection']/div[2]/a[1]"));
				JavascriptExecutor js = (JavascriptExecutor)driver;
				js.executeScript("arguments[0].click()", nextButton);
			    driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");
			 
		   }
				    
		  driver.findElement(By.xpath("//*[@id='qsubmit']")).click();
		  String hn =driver.findElement(By.xpath("//h3[text()='Your Result']")).getText();
		  System.out.println(hn);
			    
		  String ActTextDisplay=driver.findElement(By.xpath("//h3[text()='Your Result']")).getText();
   	      String ExpTextDisplay="Your Result";
   	     // driver.close();
		  Assert.assertEquals(ActTextDisplay, ExpTextDisplay);
	    	 
			
	 }
	 
	    @Test (priority=16) 
	    public void CheckVerbalTestExamTopicsFunctionality()
	    
	 {
	
			Actions actions = new Actions(driver);

	        driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div/a[7]")).click();  //Click on Logical Reasoning

	        actions.sendKeys(Keys.PAGE_DOWN).build().perform();
		      //identify element on scroll down
		    WebElement l = driver.findElement(By.xpath("//*[text()='jbktest Copyright @ 2020. All rights reserved.']"));
		    String sendit = l.getText();
	        System.out.println("Text obtained by scrolling down is :--> "+sendit);
		
	        
		    actions.sendKeys(Keys.PAGE_UP).build().perform();
		     //identify element on scroll up
	        WebElement m = driver.findElement(By.xpath("//h3[text()='Verbal Test']"));
	        String sendnow = m.getText();
	        System.out.println("Text obtained by scrolling up is :--> "+sendnow);
		     // driver.quit();    
		    
		    driver.findElement(By.xpath("//p[text()='Sentence improvement Test2']")).click(); // take a quiz of Sentence improvement Test2 10 Questions
			
			String val=driver.findElement(By.name("count")).getAttribute("value");
			System.out.println(" Attempted Questions --> " +val);
			driver.findElement(By.id("countbtn")).click();
			driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
			driver.findElement(By.id("loginbtn")).click();
			int num=Integer.parseInt(val);
			for(int i=0;i<=num+1;i++)
				
			{

				WebElement nextButton = driver.findElement(By.xpath("//*[@id='quizsection']/div[2]/a[1]"));
				JavascriptExecutor js = (JavascriptExecutor)driver;
				js.executeScript("arguments[0].click()", nextButton);
			    driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");
			 
			}
				    
		    driver.findElement(By.id("qsubmit")).click();
			String hn =driver.findElement(By.xpath("//h3[text()='Your Result']")).getText();
		    System.out.println(hn);
			    
		    String ActTextDisplay=driver.findElement(By.xpath("//*[text()='Your Result']")).getText();
		    String ExpTextDisplay="Your Result";
			//driver.close();
			Assert.assertEquals(ActTextDisplay, ExpTextDisplay);
	    	   
	 }
	    
	 
	 
	    @Test (priority=17)
	    public void CheckTotalAttemptedExamFunctionality()
	 {

			Actions actions = new Actions(driver);

			driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
			String val=driver.findElement(By.name("count")).getAttribute("value");
			System.out.println("Currently Attempted Questions --> " +val);
			driver.findElement(By.id("countbtn")).click();
			driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
			driver.findElement(By.id("loginbtn")).click();
			int num=Integer.parseInt(val);
			for(int i=0;i<=num+2;i++)
				
			{

				WebElement nextButton = driver.findElement(By.xpath("//*[@id='quizsection']/div[2]/a[1]"));
				JavascriptExecutor js = (JavascriptExecutor)driver;
				js.executeScript("arguments[0].click()", nextButton);
			    driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");
			 
			}
			
		   driver.findElement(By.id("qsubmit")).click();
		   driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
	       String TotalAttemtedQuiz = driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[1]/div/div/div/div[1]/div/h4")).getText();
           System.out.println("Total Attempted Quiz --> "+TotalAttemtedQuiz);
		   driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[1]/div/div/div/div[1]/div/a")).click(); // click on view details
			    
			    
		   WebElement CheckTotalAttemptsAndScrollDown= driver.findElement(By.xpath("/html/body/footer/div[2]/p"));
			    
	       JavascriptExecutor js = (JavascriptExecutor)driver;
 	       js.executeScript("arguments[0].scrollIntoView();",CheckTotalAttemptsAndScrollDown);
			    
	       WebElement up = driver.findElement(By.xpath("/html/body/div/div/div[2]/div/div[1]/h4"));
		   actions.sendKeys(up, Keys.ARROW_UP).perform();
			    
		   String ActualMsg = driver.findElement(By.xpath("//h4[text()='Test Attempted']")).getText();
	       String ExpectedMsg ="Test Attempted"	;
		   //driver.close();
		   Assert.assertEquals(ActualMsg, ExpectedMsg);

			    
			    
	 }
     

	   @Test (priority=18)
	   public void CheckTotalFailedExamFunctionality()
	   
	 {  
		    Actions actions = new Actions(driver);

			driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
			driver.findElement(By.id("countbtn")).click();
			driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
			driver.findElement(By.id("loginbtn")).click();
			
		    driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
		    String TotalFailedtoAttemtedQuiz = driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[3]/div/div/div/div[1]/div/h4")).getText();
	        System.out.println("Total Failed to Attempted Quiz --> " + TotalFailedtoAttemtedQuiz);
		    
		    driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[3]/div/div/div/div[1]/div/a")).click(); // click on failed to attempt
		    
		    WebElement CheckTotalFailedAttemptsAndScrollDown = driver.findElement(By.xpath("//*[text()='jbktest Copyright @ 2020. All rights reserved.']"));
		    JavascriptExecutor js = (JavascriptExecutor)driver;
	        js.executeScript("arguments[0].scrollIntoView();",CheckTotalFailedAttemptsAndScrollDown);
			
		  
	        WebElement up = driver.findElement(By.xpath("/html/body/div/div/div[2]/div/div[1]/h4"));
			actions.sendKeys(up, Keys.ARROW_UP).perform();
			
			String ActualMsg = driver.findElement(By.xpath("//*[text()='Failed Attempt']")).getText();
            String ExpectedMsg ="Failed Attempt"	;	
			//driver.close();
			Assert.assertEquals(ActualMsg, ExpectedMsg);
			
	 }
     

	   @Test (priority=19)
	   public void CheckGoodScoreFunctionality()
	   
	 {
		   
			driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
			
			driver.findElement(By.id("countbtn")).click();
			driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
			driver.findElement(By.id("loginbtn")).click();
			
			  
		    driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();// Click on Myaccount
		    
		    
		    String YourGoodScore = driver.findElement(By.xpath("//h4[text()='25']")).getText();
	        System.out.println(" Your Good Score is --> "+YourGoodScore);
	        
	        driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[2]/div/div/div/div[1]/div/a")).click();
	  
	    	
			String ActTextDisplay = driver.findElement(By.xpath("//h4[text()='Good Score']")).getText();
			String ExpTextDisplay = "Good Score";
			//driver.close();
			Assert.assertEquals(ActTextDisplay, ExpTextDisplay);
		   
		   
	   }
	   
	   
	   
	   @Test (priority=20)
	   public void CheckTimelineFunctionality()
	   
	 {

			driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
			
			driver.findElement(By.id("countbtn")).click();
			driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
			driver.findElement(By.id("loginbtn")).click();
			
		    driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
		    String TextDisplay = driver.findElement(By.xpath("//*[text()='Timeline']")).getText();
	        System.out.println( TextDisplay);
		    
		    driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[4]/div/div/div/div[1]/div/a")).click();  // click on view details
		   
		    String ActTextDisplay = driver.findElement(By.xpath("/html/body/div/div/div[2]/div/a/span")).getText();
		    String ExpTextDisplay = "Back";
			//driver.close();
			Assert.assertEquals(ActTextDisplay, ExpTextDisplay);
		   
	 }
	   
	   

	   @Test (priority=21)
	   public void CheckTotalTopicsCoveredFunctionality(){
			
			

			driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
			
			driver.findElement(By.id("countbtn")).click();
			driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
			driver.findElement(By.id("loginbtn")).click();
			
		    driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
		    String MessageDisplay = driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[5]/div/div/div/div[1]/div/h4")).getText();
	        System.out.println(" Total Topics Covered --> " + MessageDisplay);
		    
		    driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[5]/div/div/div/div[1]/div/a")).click();  // click on view details
		   
		    String ActTextDisplay = driver.findElement(By.xpath("/html/body/div/div/div[2]/div/a/span")).getText();
		    String ExpTextDisplay = "Back";
			//driver.close();
			Assert.assertEquals(ActTextDisplay, ExpTextDisplay);
		   
		   
	   }

	   @Test (priority=22)
	   public void CheckUpdateFunctionality()
	   
	{
	
			driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();

			driver.findElement(By.id("countbtn")).click();
			driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
			driver.findElement(By.id("loginbtn")).click();
			
			driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
			driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[6]/div/div/div/div[1]/div/a")).click();
			driver.findElement(By.id("name")).clear();
			driver.findElement(By.id("emailid")).clear();
			driver.findElement(By.id("mobile")).clear();
			
			driver.findElement(By.id("name")).sendKeys("Sagar Ade");
			driver.findElement(By.id("emailid")).sendKeys("sagaradae2022@gmail.com");
			driver.findElement(By.id("mobile")).sendKeys("8446312847");
			driver.findElement(By.id("updatebtn")).click();
			
			String expectedMessage = "Profile successfully updated";
			String actualMessage = driver.findElement(By.xpath("//*[text()='Profile successfully updated']")).getText();
			//driver.close();
			Assert.assertEquals(actualMessage, expectedMessage);
    }
	   
	   
	   @Test (priority=23)
	   public void CheckContributePageFunctionality()
	   
	{

	       driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[1]/a")).click();
	  	   driver.findElement(By.xpath("//*[@id='navbarResponsive']/div/a")).click();
	  	   driver.findElement(By.name("first_name")).sendKeys("sagar");
	       driver.findElement(By.name("email")).sendKeys("sagar1234@gmail.com");
	  	   driver.findElement(By.name("phone_number")).sendKeys("8446312847");
           driver.findElement(By.name("submit")).click();
	            
           String ActMessage =  driver.findElement(By.id("mail_success")).getText();
	       String ExpMessage = "Mail Sent. Thank you sagar, we will contact you shortly.";
           System.out.println(ActMessage);
		   //driver.close();
		   Assert.assertEquals(ActMessage, ExpMessage);
	                       

	    	   
	 }
	   
	   
	   
	   @Test (priority=24)
	   public void ChecLogoutFunctionality()
	  
	 {
	 
	        driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();	
	    	driver.findElement(By.id("countbtn")).click();
	    	driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
	    	driver.findElement(By.id("loginbtn")).click();
	    		  
	           
	  	    driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
	   	    driver.findElement(By.xpath("//a[text()='Logout']")).click();
	    	    
    	    String ActHomePage =  driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div[1]/div[2]/p")).getText();
	        String ExpHomePage = "Check your experties & improve your skills";
			//driver.close();
			Assert.assertEquals(ActHomePage, ExpHomePage);
	                

	 }
	 
	   
	   
	
	
	
	
	
	
}
