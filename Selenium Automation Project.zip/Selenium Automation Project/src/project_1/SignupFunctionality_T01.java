package project_1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SignupFunctionality_T01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Actions actions = new Actions(driver);
		driver.findElement(By.xpath("//p[text()='Manual Testing(ISTQB)']")).click();
		driver.findElement(By.id("countbtn")).click();
		driver.findElement(By.id("loginmobile")).sendKeys("2222211111");
		driver.findElement(By.id("loginbtn")).click();
		driver.findElement(By.id("signup-tab")).click();
		driver.findElement(By.id("name")).sendKeys("sagar Ade");
		driver.findElement(By.id("emailid")).sendKeys("sagarade2061999@gmail.com");
		
		driver.findElement(By.id("mobile")).sendKeys("8446312847");
	    driver.findElement(By.id("agree")).click();
	    actions.sendKeys(Keys.ARROW_DOWN).perform();

		driver.findElement(By.id("emailbtn")).click();
			  
				
			
	}

}
