package project_1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DownloadCertificateFunctionality_T06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		 driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[1]/a")).click();
		 driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div[1]/div[2]/h1/a")).click();
		 driver.findElement(By.xpath("//*[@id='Placement-Policy']/div/div/a/div")).click();
		 
		 String val=driver.findElement(By.name("count")).getAttribute("value");
			System.out.println(val);
			driver.findElement(By.id("countbtn")).click();
			
			driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
			driver.findElement(By.id("loginbtn")).click();
			driver.findElement(By.xpath("//*[@id='choices']/div[1]/label/div")).click();
			int num=Integer.parseInt(val);
			for(int i=0;i<=num+1;i++)
			{

				WebElement nextButton = driver.findElement(By.xpath("//*[@id='quizsection']/div[2]/a[1]"));
				JavascriptExecutor js = (JavascriptExecutor)driver;
				js.executeScript("arguments[0].click()", nextButton);
				 driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");
			 
			}
			
			   driver.findElement(By.id("qsubmit")).click();
			   driver.findElement(By.xpath("//*[text()='Download Your Certificate']")).click();
		
	}

}
