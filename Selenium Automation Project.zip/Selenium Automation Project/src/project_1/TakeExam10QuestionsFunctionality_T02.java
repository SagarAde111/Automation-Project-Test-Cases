package project_1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class TakeExam10QuestionsFunctionality_T02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		  driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
	      	String val=driver.findElement(By.name("count")).getAttribute("value");
		    System.out.println(" Attempted Questions --> " +val);
		    driver.findElement(By.id("countbtn")).click();
		    driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
		    driver.findElement(By.id("loginbtn")).click();
		    int num=Integer.parseInt(val);
		    for(int i=0;i<=num+1;i++)
		    	
	      {

			WebElement nextButton = driver.findElement(By.xpath("//*[@id='quizsection']/div[2]/a[1]"));
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("arguments[0].click()", nextButton);
		    driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");
		 
		  }
		
	    	    
		    driver.findElement(By.xpath("//*[text()='Submit']")).click();
		    String msg =driver.findElement(By.xpath("//*[text()='Your Result']")).getText();
		    System.out.println(msg);

}
}