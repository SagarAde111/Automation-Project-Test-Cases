package project_1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class AptitudeTestFunctionality_T14 {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");
		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Actions actions = new Actions(driver);

        driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div/a[4]")).click();  //Click on Aptitude Test

        actions.sendKeys(Keys.PAGE_DOWN).build().perform();
	      //identify element on scroll down
	      WebElement l = driver.findElement(By.xpath("//*[text()='jbktest Copyright @ 2020. All rights reserved.']"));
	      String sendit = l.getText();
	      System.out.println("Text obtained by scrolling down is :--> "+sendit);
	      
	      actions.sendKeys(Keys.PAGE_UP).build().perform();
	      //identify element on scroll up
	      WebElement m = driver.findElement(By.xpath("//*[text()='Aptitude Test']"));
	      String sendnow = m.getText();
	      System.out.println("Text obtained by scrolling up is :--> "+sendnow);
	     // driver.quit();    
	    
	driver.findElement(By.xpath("//*[text()='Aptitude Test 1']")).click(); // take a quiz of Aptitude Test 1
		
		String val=driver.findElement(By.name("count")).getAttribute("value");
		System.out.println("Attempted Questions --> " +val);
		driver.findElement(By.id("countbtn")).click();
		driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
		driver.findElement(By.id("loginbtn")).click();
		int num=Integer.parseInt(val);
		for(int i=0;i<=num+1;i++)
		{

			WebElement nextButton = driver.findElement(By.xpath("//*[@id='quizsection']/div[2]/a[1]"));
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("arguments[0].click()", nextButton);
			 driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");
		 
		}
			    
		    driver.findElement(By.id("qsubmit")).click();
		    String hn =driver.findElement(By.xpath("//h3[text()='Your Result']")).getText();
		    System.out.println(hn);
		    
		
		
		
	}

}
