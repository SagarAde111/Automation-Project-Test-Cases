package project_1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class JavaExamTopicsFunctionality_T9 {

	public static void main(String[] args) {


		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");
		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Actions actions = new Actions(driver);

		driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();

		driver.findElement(By.id("countbtn")).click();
		driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
		driver.findElement(By.id("loginbtn")).click();
		driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
		driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[1]/a")).click(); // click on Home 
		
		
	    driver.findElement(By.xpath("/html/body/div/div[1]/div[1]/div[3]/div[1]/a/div")).click();  // click on java test Topics
		    
    
	   actions.sendKeys(Keys.PAGE_DOWN).build().perform();
	      //identify element on scroll down
	      WebElement l = driver.findElement(By.xpath("//*[text()='jbktest Copyright @ 2020. All rights reserved.']"));
	      String sendit = l.getText();
	      System.out.println("Text obtained by scrolling down is :--> "+sendit);
	      
	      actions.sendKeys(Keys.PAGE_UP).build().perform();
	      //identify element on scroll up
	      WebElement m = driver.findElement(By.xpath("//h3[text()='Java']"));
	      String sendnow = m.getText();
	      System.out.println("Text obtained by scrolling up is :--> "+sendnow);
	     // driver.quit();    
	    
		
	}

}
