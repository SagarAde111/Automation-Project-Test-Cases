package project_1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ContributePageFunctionality_T23 {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		 driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[1]/a")).click();
	    driver.findElement(By.xpath("//*[@id='navbarResponsive']/div/a")).click();
	    driver.findElement(By.name("first_name")).sendKeys("sagar");
	    driver.findElement(By.name("email")).sendKeys("sagar1234@gmail.com");
	    driver.findElement(By.name("phone_number")).sendKeys("1234123444");
        driver.findElement(By.name("submit")).click();
        
         String getMessage =  driver.findElement(By.id("mail_success")).getText();
         System.out.println(getMessage);
        

	    

	}

}
