package project_1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TotalFailedToAttemptedQuizFunctionality_T18 {

	public static void main(String[] args) {

		
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Actions actions = new Actions(driver);

		driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
		
		driver.findElement(By.id("countbtn")).click();
		driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
		driver.findElement(By.id("loginbtn")).click();
		
	    driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
	    String TotalFailedtoAttemtedQuiz = driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[3]/div/div/div/div[1]/div/h4")).getText();
        System.out.println("Total Failed to Attempted Quiz --> " + TotalFailedtoAttemtedQuiz);
	    
	    driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[3]/div/div/div/div[1]/div/a")).click();  // click on view details
	    
	    WebElement CheckTotalFailedAttemptsAndScrollDown = driver.findElement(By.xpath("//*[text()='jbktest Copyright @ 2020. All rights reserved.']"));
	    JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("arguments[0].scrollIntoView();",CheckTotalFailedAttemptsAndScrollDown);
		
	    String TextDisplay = driver.findElement(By.xpath("/html/body/div/div/div[2]/div/div[1]/h4")).getText();
        System.out.println(TextDisplay);
       
        WebElement up = driver.findElement(By.xpath("/html/body/div/div/div[2]/div/div[1]/h4"));
	    actions.sendKeys(up, Keys.ARROW_UP).perform();

	}

}
