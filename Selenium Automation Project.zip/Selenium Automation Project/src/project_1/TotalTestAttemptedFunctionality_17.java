package project_1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TotalTestAttemptedFunctionality_17 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
		
		String val=driver.findElement(By.name("count")).getAttribute("value");
		System.out.println(val);
		driver.findElement(By.id("countbtn")).click();
		driver.findElement(By.id("loginmobile")).sendKeys("8446312847");
		driver.findElement(By.id("loginbtn")).click();
		int num=Integer.parseInt(val);
		for(int i=0;i<=num+2;i++)
		{

			WebElement nextButton = driver.findElement(By.xpath("//*[@id='quizsection']/div[2]/a[1]"));
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("arguments[0].click()", nextButton);
			 driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");
			 
		 
		}
		
		    driver.findElement(By.id("qsubmit")).click();
		    driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
		    String TotalAttemtedQuiz = driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[1]/div/div/div/div[1]/div/h4")).getText();
	        System.out.println("Total Attempted Quiz --> "+TotalAttemtedQuiz);
		    driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[1]/div/div/div/div[1]/div/a")).click(); // click on view details
		    
		    
		    WebElement CheckTotalAttemptsAndScrollDown= driver.findElement(By.xpath("/html/body/footer/div[2]/p"));
		    
		    JavascriptExecutor js = (JavascriptExecutor)driver;
		    js.executeScript("arguments[0].scrollIntoView();",CheckTotalAttemptsAndScrollDown);
		    
		    String TextDisplay = driver.findElement(By.xpath("//*[text()='jbktest Copyright @ 2020. All rights reserved.']")).getText();
		    System.out.println(TextDisplay);
		    
		    
		    
		
		    
		
	}

}
